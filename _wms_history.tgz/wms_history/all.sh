# 1. 计算总版本数并减去 2
count=$(( $(git rev-list --count HEAD) - 3 ))

# 2. 如果计算出的数量大于0，则进行遍历，存入 all_wms.txt
if [ $count -gt 0 ]; then
  > all_wms.txt  # 清空或创建 all_wms.txt 文件，防止历史数据干扰
  
  # --- 第一个循环 ---
  for i in $(git rev-list HEAD --max-count=$count); do
    echo "版本ID: $i" >> all_wms.txt
    # 修改点：直接在 echo 中使用 $() 获取时间
    echo "时间: $(git show -s --format=%cd --date=format:'%Y-%m-%d %H:%M:%S' "$i")" >> all_wms.txt
    git show "$i":wms.txt >> all_wms.txt
    echo >> all_wms.txt
    echo >> all_wms.txt
  done
  
  # --- 第二个循环 ---
  # --skip=$count 跳过前面已经处理的版本，--max-count=2 只取最后的2个
  for i in $(git rev-list HEAD --skip=$count --max-count=2); do
    echo "版本ID: $i" >> all_wms.txt
    # 修改点：直接在 echo 中使用 $() 获取时间
    echo "时间: $(git show -s --format=%cd --date=format:'%Y-%m-%d %H:%M:%S' "$i")" >> all_wms.txt
    git show "$i":简易仓库系统.txt >> all_wms.txt
    echo >> all_wms.txt
    echo >> all_wms.txt
  done
else
  echo "总版本数不超过2个，无法分割。"
fi
