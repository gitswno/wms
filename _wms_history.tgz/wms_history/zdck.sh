
as='adb shell'

# 自动出库按钮坐标
$as input tap 540 371

# 等1秒扫码时间
sleep 2

# 然后点确定出库
$as input tap 750 1403
sleep 1
# 打勾
$as input tap 76 523
sleep 1
# 出库类型控件坐标
$as input tap 571 830
sleep 1
# 选默认的其它，直接右下角确定
$as input tap 708 2251
# 粘贴
sleep 1
$as input tap 405 1010
sleep 1
$as input swipe 505 2046 505 2250
sleep 1
# 拍照片的加号
$as input tap 406 1186
sleep 1
$as input tap 604 2041
sleep 1
# 拍照按钮
$as input tap 556 2195
sleep 0.6
#完成按钮
$as input tap 994 2285
sleep 1
# 备注框
$as input tap 296 1741
sleep 0.5
$as input swipe 505 2046 505 2250
sleep 0.5

#隐藏键盘
$as input swipe 1009 1634.5 1009 1834.5
sleep 0.5
# 下面确定出库按钮
$as input tap 511 2126.5
sleep 0.5
#左滑返回
$as input swipe 1080 1636 780 1636
sleep 0.5
# 异常处理坐标
$as input tap 878 994
sleep 0.5
