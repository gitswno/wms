#!/bin/sh

# 检查是否输入了关键字
if [ -z "$1" ]; then
    echo "用法: $0 <keyword>"
    echo "示例: $0 hello"
    exit 1
fi

# 检查文件是否存在
FILE="/storage/emulated/0/Download/wms/wms.txt"
if [ ! -f "$FILE" ]; then
    echo "错误: 找不到文件 $FILE"
    exit 1
fi

KEYWORD="$1"

# grep -n 获取带行号的结果，逐行处理
grep -n "$KEYWORD" "$FILE" | while IFS=: read -r line_num line_content; do
    
    # 先打印关键字所在的当前行（第50行）
    echo "【关键字行】 第 ${line_num} 行: ${line_content}"
    
    # 检查当前行自身是否包含英文冒号
    if echo "$line_content" | grep -q ':'; then
        echo "  └─ 该行自身包含冒号，无需往上查找。"
    else
        # 往前逐行搜索第一个冒号
        i=$((line_num - 1))
        
        while [ "$i" -gt 0 ]; do
            # 使用 sed 提取第 i 行的内容
            current_line=$(sed -n "${i}p" "$FILE")
            
            # 检查该行是否包含英文冒号
            if echo "$current_line" | grep -q ':'; then
                # 找到了，打印冒号所在行（第35行）
                echo "【冒号所在行】 第 ${i} 行: ${current_line}"
                break # 找到后停止往前搜索
            fi
            i=$((i - 1))
        done
        
        # 如果一直往前找都没找到冒号行，给个提示
        if [ "$i" -le 0 ]; then
            echo "  └─ 往前搜索到第1行，未发现包含冒号的行。"
        fi
    fi
    
    echo "----------------------------------------" # 分隔线，区分不同的匹配结果
done
